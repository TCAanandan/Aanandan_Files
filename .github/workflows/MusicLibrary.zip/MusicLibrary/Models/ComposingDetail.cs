﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MusicLibrary.Models
{
    public class ComposingDetail
    {
        [Key]
        public Int32 ID { get; set; }
        public string TitleName { get; set;}
        public string AlbumName { get; set; }
        public string ComposerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-mm-yyyy}")]
        public string Releasedate { get; set; }
        public string ArtistName { get; set; }

    }
}
