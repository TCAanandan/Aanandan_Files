﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MusicLibrary.Models;


namespace MusicLibrary.Data
{
    public class ComposingService
    {
        private ApplicationDbContext _context;
        public ComposingService(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(ComposingDetail composingDtl)
        {
            _context.Add(composingDtl);
            _context.SaveChanges();
        }
    }
}
