﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MusicLibrary.Models;
using MusicLibrary.Data;

namespace MusicLibrary.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private ApplicationDbContext _context;
        public ComposingDetail compdtl;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;

            if (_context.composingDetails.Count()==0)
            {
                ComposingDetail compdtl = new ComposingDetail();
                compdtl.ID = 1;
                compdtl.TitleName = "Vande Mataram";
                compdtl.AlbumName = "Vande Mataram";
                compdtl.ComposerName = "AR Rahman";
                //compdtl.Releasedate = Convert.ToDateTime("15/08/2000");
                compdtl.Releasedate = "15/08/2000";
                compdtl.ArtistName = "Rahman";
                _context.composingDetails.Add(compdtl);
                _context.SaveChanges();

                compdtl = null;

                compdtl = new ComposingDetail();
                compdtl.ID = 2;
                compdtl.TitleName = "Thental";
                compdtl.AlbumName = "Thental Varum";
                compdtl.ComposerName = "Ialayraja ";
                //compdtl.Releasedate = Convert.ToDateTime("15/10/2000");
                compdtl.Releasedate = "15/10/2000";
                compdtl.ArtistName = "Janaki";
                _context.composingDetails.Add(compdtl);
                _context.SaveChanges();
                compdtl = null;

            }


        }

        public IActionResult Privacy()
        {
            return View();
        }

        
        public IActionResult AddAlbum()
        {

            compdtl = null;
            compdtl = new ComposingDetail();
            return View(compdtl);
        }

        [HttpPost]
        public IActionResult AddAlbum([Bind("ID,TitleName,AlbumName,ComposerName,Releasedate,ArtistName")] ComposingDetail composingDtl)
        {
            Int32 albumId = _context.composingDetails.Max(x => x.ID);
            composingDtl.ID = albumId + 1;

            _context.composingDetails.Add(composingDtl);
            _context.SaveChanges();
            compdtl = null;

            compdtl = new ComposingDetail();
            //return View(compdtl);
            return RedirectToAction("Index");

        }
        public IActionResult Index(string columnName, string searchString)
        {
            List<ComposingDetail> ListAlbum = null;

            if (columnName== "TitleName" && searchString!=null)
            {
                ListAlbum = _context.composingDetails.Where(x => x.TitleName.Contains(searchString)).ToList();
            }
            else if (columnName== "AlbumName" && searchString != null)
            {
                ListAlbum = _context.composingDetails.Where(x => x.AlbumName.Contains(searchString)).ToList();
            }
            else if (columnName == "ComposerName" && searchString != null)
            {
                ListAlbum = _context.composingDetails.Where(x => x.ComposerName.Contains(searchString)).ToList();
            }
            else if (columnName == "ArtistName" && searchString != null)
            {
                ListAlbum = _context.composingDetails.Where(x => x.ArtistName.Contains(searchString)).ToList();
            }
            else
            {
                ListAlbum = _context.composingDetails.ToList();
            }

            ViewBag.searchString = searchString;
            return View(ListAlbum.ToList());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
